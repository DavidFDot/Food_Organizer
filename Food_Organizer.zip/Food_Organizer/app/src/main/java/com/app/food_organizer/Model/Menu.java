package com.app.food_organizer.Model;

import java.util.ArrayList;

public class Menu {
    private String nombre;
    private ArrayList<Platillos> mPlatillos;

}
