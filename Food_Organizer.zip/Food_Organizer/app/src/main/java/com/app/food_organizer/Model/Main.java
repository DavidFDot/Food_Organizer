package com.app.food_organizer.Model;

import java.util.ArrayList;

public class Main {
    private ArrayList<Menu> mMenus;

}
