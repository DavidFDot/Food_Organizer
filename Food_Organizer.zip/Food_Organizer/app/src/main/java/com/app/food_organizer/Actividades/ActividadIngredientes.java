package com.app.food_organizer.Actividades;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ActividadIngredientes extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad_ingredientes);
    }
}