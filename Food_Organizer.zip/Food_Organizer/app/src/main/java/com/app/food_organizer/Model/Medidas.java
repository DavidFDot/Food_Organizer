package com.app.food_organizer.Model;

public enum Medidas {
}
