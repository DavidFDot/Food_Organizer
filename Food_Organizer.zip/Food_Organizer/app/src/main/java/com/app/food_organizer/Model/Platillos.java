package com.app.food_organizer.Model;

import java.util.ArrayList;

public class Platillos {
    private String mNombre;
    private ArrayList<Platillos> mPlatillos;

}
