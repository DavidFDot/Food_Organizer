package com.app.food_organizer.Model;

public class Ingredientes {
    private String mNombre;
    private int cantidad;
    private Medidas mMedidas;
}
